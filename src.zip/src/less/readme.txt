open the app.variables.less to change the variables

http://localhost/todo/less/less.php?app.less
use the compiled css to replace the css/app.css

http://localhost/todo/less/less.php?app.plugin.less
use the compiled css to replace the css/plugin.css