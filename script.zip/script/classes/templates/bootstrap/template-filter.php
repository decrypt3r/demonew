<section class="panel">
    <header class="panel-heading">
        <?php echo $displayText; ?>
    </header>
    <div class="panel-body">
        <?php echo $filterControl; ?>
    </div>
</section>