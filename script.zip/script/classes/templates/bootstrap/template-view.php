<section class="pdocrud-table-container" data-objkey="<?php echo $objKey; ?>">
    <div id="pdocrud-table-view table-responsive">
        <?php echo $output; ?>
    </div>
</section>