<table>
<?php
foreach ($data as $key => $val) {?>
<tr>
    <td><?php echo $key; ?></td>
    <td><?php echo $val; ?></td>
</tr>
<?php } ?>
</table>